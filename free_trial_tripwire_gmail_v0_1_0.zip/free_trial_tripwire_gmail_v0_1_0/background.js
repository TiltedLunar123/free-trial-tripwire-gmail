﻿// background.js

// URL match for Gmail tabs
const GMAIL_URL_MATCH = "*://mail.google.com/*";

const MSG = {
  START_SCAN: "FTT_START_SCAN",      // from popup → background
  SCAN_RESULTS: "FTT_SCAN_RESULTS",  // from gmailScanner → background
  GET_TRIALS: "FTT_GET_TRIALS",      // from popup → background
  TRIALS_UPDATED: "FTT_TRIALS_UPDATED",
  PROGRESS: "FTT_PROGRESS"
};

// ------------ Small helpers ------------

function sendProgress(stage, details) {
  try {
    chrome.runtime.sendMessage({
      type: MSG.PROGRESS,
      stage,
      details: details || null
    });
  } catch (e) {
    // ok if no listeners
  }
}

function queryTabs(query) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query(query, tabs => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(tabs);
      }
    });
  });
}

function createTab(createProps) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create(createProps, tab => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(tab);
      }
    });
  });
}

function executeScript(target, files) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      { target, files },
      results => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(results);
        }
      }
    );
  });
}

function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, result => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result);
      }
    });
  });
}

function storageSet(items) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(items, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}

function waitForTabComplete(tabId) {
  return new Promise(resolve => {
    function listener(updatedId, changeInfo, tab) {
      if (updatedId === tabId && changeInfo.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// ------------ Core logic ------------

async function findOrOpenGmailTab() {
  const tabs = await queryTabs({ url: GMAIL_URL_MATCH });

  if (tabs && tabs.length > 0) {
    return tabs[0];
  }

  sendProgress("opening_gmail", "No Gmail tab found, opening inbox.");
  const newTab = await createTab({
    url: "https://mail.google.com/mail/u/0/#inbox",
    active: true
  });

  await waitForTabComplete(newTab.id);
  return newTab;
}

async function runGmailScan() {
  sendProgress("starting", "Locating Gmail tab...");
  const gmailTab = await findOrOpenGmailTab();

  sendProgress("injecting", "Injecting scanner into Gmail...");
  await executeScript({ tabId: gmailTab.id }, ["gmailScanner.js"]);

  // gmailScanner.js is responsible for scanning and sending
  // a message { type: MSG.SCAN_RESULTS, trials: [...] }
  sendProgress("waiting_results", "Waiting for scan results...");
}

async function mergeTrials(newTrials) {
  if (!Array.isArray(newTrials) || newTrials.length === 0) return;

  const data = await storageGet(["trialsById"]);
  const trialsById = data.trialsById || {};

  for (const t of newTrials) {
    if (!t || !t.id) continue;
    const existing = trialsById[t.id] || {};
    trialsById[t.id] = Object.assign({}, existing, t);
  }

  const lastScanAt = Date.now();
  await storageSet({ trialsById, lastScanAt });

  try {
    chrome.runtime.sendMessage({
      type: MSG.TRIALS_UPDATED,
      lastScanAt,
      trials: Object.values(trialsById)
    });
  } catch (e) {
    // fine if popup isn't open
  }
}

// ------------ Message routing ------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  // Popup → start a scan
  if (message.type === MSG.START_SCAN) {
    (async () => {
      try {
        await runGmailScan();
        sendResponse({ ok: true });
      } catch (err) {
        console.error("[FTT] Scan failed", err);
        sendProgress("error", String(err && err.message || err));
        sendResponse({ ok: false, error: String(err && err.message || err) });
      }
    })();
    return true; // keep sendResponse alive
  }

  // gmailScanner → results
  if (message.type === MSG.SCAN_RESULTS) {
    (async () => {
      try {
        await mergeTrials(message.trials || []);
      } catch (err) {
        console.error("[FTT] Failed to merge trials", err);
      }
    })();
    // no response needed
  }

  // Popup → load existing trials
  if (message.type === MSG.GET_TRIALS) {
    (async () => {
      try {
        const data = await storageGet(["trialsById", "lastScanAt"]);
        const trialsById = data.trialsById || {};
        sendResponse({
          ok: true,
          trials: Object.values(trialsById),
          lastScanAt: data.lastScanAt || null
        });
      } catch (err) {
        console.error("[FTT] Failed to load trials", err);
        sendResponse({
          ok: false,
          error: String(err && err.message || err)
        });
      }
    })();
    return true;
  }
});
