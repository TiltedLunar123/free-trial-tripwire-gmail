﻿# Free-Trial Tripwire for Gmail

Free-Trial Tripwire is a Chrome extension that scans your Gmail inbox **locally** to find:

- Free trials that are about to convert to paid  
- New subscriptions and auto-renewals  
- Upcoming charges with dates and amounts (when detectable)

It then lets you **generate calendar reminders** to cancel before you’re billed, and gives you a clean dashboard of “at-risk” subscriptions.

> All scanning happens in your browser. No data is sent to any server.

---

## Features

- 🔍 **One-click Gmail scan**  
  - Scans the current Gmail inbox view (no login, no API keys)  
  - Looks for phrases like “free trial”, “upcoming charge”, “auto-renew”, etc.  
  - Detects both **trials** and **subscriptions**

- 📊 **Dashboard inside the popup**  
  - Table of detected emails with:
    - Service name  
    - Type: **Trial** / **Sub**  
    - Next charge date (when found)  
    - Amount (when found)  
  - Filters: **All / Trials / Subs**  
  - Summary of:
    - Number of watched emails  
    - Total “at-risk” amount

- ⏰ **Cancel-reminder generator (.ics)**  
  - Per-row **“Remind”** button  
  - Creates a calendar event (ICS file):
    - Title: `Cancel [Service]`  
    - Time: 1 day before the detected charge date at 9:00 am  
    - Includes amount + link back to the original Gmail thread (when available)

- 💸 **Tip-friendly UX**  
  - Shows estimated total amount you’re protecting  
  - Subtle CTA to tip if it saved you more than a coffee

---

## How it works (high level)

1. You open Gmail and click the extension icon → **“Scan inbox”**.  
2. The background script injects `gmailScanner.js` into the current Gmail tab.  
3. `gmailScanner.js`:
   - Reads the visible message rows (subject, snippet, sender, link)  
   - Runs simple keyword + pattern matching  
   - Tries to extract charge **amounts** and **dates** from the text  
   - Returns a list of “trial/subscription” objects to the background script  
4. The background script merges results into `chrome.storage.local`.  
5. The popup reads from storage and renders the dashboard UI.

No Gmail API, no external requests, no servers.

---

## Privacy & data

- Runs **entirely in your browser**.  
- Only uses DOM of the Gmail tab:
  - Reads sender, subject, snippet, and visible row text.  
  - Does *not* upload content anywhere.  
- Uses `chrome.storage.local` to store:
  - Detected trials/subscriptions  
  - Last scan time  
- No analytics, no trackers, no remote config.

If you’re paranoid (reasonable), you can inspect:

- `manifest.json` for permissions  
- `background.js`, `gmailScanner.js`, and `popup.js` for behavior

---

## Permissions

From `manifest.json`:

- `"tabs"` – to find/open your Gmail tab  
- `"scripting"` – to inject the scanner into Gmail  
- `"storage"` – to save detected trials/subs locally  
- `"host_permissions": ["https://mail.google.com/*"]` – to allow scripts to run on Gmail

No `identity`, no external URLs.

---

## Installation (developer / unpacked)

Until it’s in the Chrome Web Store, install as an unpacked extension:

1. Clone/download this repo or copy the folder (e.g. `free_trial_tripwire_gmail_v0_1_0`).  
2. Open Chrome and go to `chrome://extensions`.  
3. Turn on **Developer mode** (top right).  
4. Click **“Load unpacked”**.  
5. Select the extension folder (the one containing `manifest.json`).  

You should see **Free-Trial Tripwire for Gmail** appear in your extension list.

---

## Usage

1. Open Gmail in Chrome (`https://mail.google.com`), in your usual inbox view.  
2. Click the extension icon → popup opens.  
3. Hit **“Scan inbox”**:
   - Status pill will show progress (“Scanning Gmail…”, etc.).  
   - After a few seconds, any detected trials/subs appear in the table.  
4. Filter between **All / Trials / Subs** as needed.  
5. For anything important:
   - Click **“Remind”** next to the amount to download a `.ics` reminder.  
   - Open it with Google Calendar / your calendar app to add the event.

Tip: You can re-run scans after new emails come in.

---

## Limitations & known quirks

- Only scans the **current inbox view** (not your whole historical archive).  
- Detection is **keyword-based**, so:
  - Some legitimate subs might be missed.  
  - Some emails may be false positives if they mention those phrases.  
- Date/amount parsing is best-effort and depends on email formatting.  
- Gmail’s CSS/DOM may change over time, which could break row detection.

This is designed as a **helpful tripwire**, not a flawless billing tracker. Always double-check anything critical.

---

## Support & tips

If this saved you from a surprise charge and you want to say thanks:

- Cash App: [`$judeh1l`](https://cash.app/$judeh1l)  
- Buy Me a Coffee: [`buymeacoffee.com/judeh1l`](https://www.buymeacoffee.com/judeh1l)

Bug reports and suggestions are welcome.  
You can open an issue on the repo or tweak the code and submit a PR.
