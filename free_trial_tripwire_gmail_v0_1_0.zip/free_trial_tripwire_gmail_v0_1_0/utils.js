﻿// utils.js
// Generic helpers for Free-Trial Tripwire.
//
// Exposes global FTTUtils with:
// - sleep(ms)
// - formatCurrency(amount, currency)
// - formatDate(isoString)
// - parseAmountFromText(text)
// - parseDateFromText(text)

(function initFTTUtils(global) {
  if (!global) return;

  const MONTH_NAMES = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december"
  ];

  // -------- timing --------

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // -------- formatting --------

  function formatCurrency(amount, currency = "USD") {
    if (typeof amount !== "number" || isNaN(amount)) return null;
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency
      }).format(amount);
    } catch (e) {
      return `$${amount.toFixed(2)}`;
    }
  }

  function formatDate(iso) {
    if (!iso) return null;
    const d = new Date(iso);
    if (isNaN(d.getTime())) return null;
    return d.toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  }

  // -------- parsing from text --------

  function parseAmountFromText(text) {
    if (!text) return { amount: null, currency: null };
    const dollarMatch = text.match(/\$\s*(\d{1,4}(?:\.\d{1,2})?)/);
    if (!dollarMatch) return { amount: null, currency: null };

    const num = parseFloat(dollarMatch[1]);
    if (isNaN(num)) return { amount: null, currency: null };

    return { amount: num, currency: "USD" };
  }

  function parseDateFromText(text) {
    if (!text) return null;
    const lower = text.toLowerCase();

    // Month-name style: "January 5, 2026" or "Jan 5"
    const monthRegex = new RegExp(
      "\\b(" + MONTH_NAMES.join("|") + ")\\s+\\d{1,2}(?:,\\s*\\d{2,4})?",
      "i"
    );
    const monthMatch = text.match(monthRegex);
    if (monthMatch) {
      const raw = monthMatch[0];
      const d = new Date(raw);
      if (!isNaN(d.getTime())) return d.toISOString();
    }

    // Numeric dates: 01/05/2026, 1/5/26, etc.
    const numericMatch = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
    if (numericMatch) {
      const [, mm, dd, yyyy] = numericMatch;
      let year = parseInt(yyyy, 10);
      if (year < 100) year += 2000;
      const month = parseInt(mm, 10) - 1;
      const day = parseInt(dd, 10);
      const d = new Date(year, month, day);
      if (!isNaN(d.getTime())) return d.toISOString();
    }

    // ISO-like: 2026-01-05
    const isoMatch = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      const d = new Date(isoMatch[0]);
      if (!isNaN(d.getTime())) return d.toISOString();
    }

    return null;
  }

  const api = {
    sleep,
    formatCurrency,
    formatDate,
    parseAmountFromText,
    parseDateFromText
  };

  global.FTTUtils = api;
})(
  typeof globalThis !== "undefined"
    ? globalThis
    : typeof self !== "undefined"
    ? self
    : typeof window !== "undefined"
    ? window
    : this
);
