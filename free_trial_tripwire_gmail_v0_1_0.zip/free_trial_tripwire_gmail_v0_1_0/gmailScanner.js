﻿// gmailScanner.js
// Runs inside the Gmail tab. Scans the current message list view
// and reports suspected trials/subscriptions back to the background script.

(() => {
  const MSG = {
    SCAN_RESULTS: "FTT_SCAN_RESULTS",
    PROGRESS: "FTT_PROGRESS"
  };

  function sendProgress(stage, details) {
    try {
      chrome.runtime.sendMessage({
        type: MSG.PROGRESS,
        stage,
        details: details || null,
        source: "gmailScanner"
      });
    } catch (e) {
      // fine if nobody is listening
    }
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // ---------------- Detection helpers ----------------

  const TRIAL_KEYWORDS = [
    "free trial",
    "trial period",
    "your trial ends",
    "trial ending",
    "trial expires",
    "trial expiration",
    "start of your trial",
    "trial started"
  ];

  const SUB_KEYWORDS = [
    "your subscription",
    "subscription started",
    "subscription is now active",
    "thanks for subscribing",
    "you have subscribed",
    "auto-renew",
    "auto renew",
    "automatic renewal",
    "upcoming charge",
    "upcoming payment",
    "will be charged",
    "will be billed",
    "next bill",
    "next billing date",
    "payment scheduled",
    "renews on",
    "renews at"
  ];

  const MONTH_NAMES = [
    "january", "february", "march", "april", "may", "june",
    "july", "august", "september", "october", "november", "december"
  ];

  function detectTypeAndSource(subject, snippet) {
    const s = (subject || "").toLowerCase();
    const sn = (snippet || "").toLowerCase();

    let type = "unknown";
    let source = null;

    const checkList = (text, list) => list.some(k => text.includes(k));

    if (checkList(s, TRIAL_KEYWORDS) || checkList(sn, TRIAL_KEYWORDS)) {
      type = "trial";
      if (checkList(s, TRIAL_KEYWORDS) && checkList(sn, TRIAL_KEYWORDS)) {
        source = "both";
      } else if (checkList(s, TRIAL_KEYWORDS)) {
        source = "subject";
      } else {
        source = "snippet";
      }
    } else if (checkList(s, SUB_KEYWORDS) || checkList(sn, SUB_KEYWORDS)) {
      type = "subscription";
      if (checkList(s, SUB_KEYWORDS) && checkList(sn, SUB_KEYWORDS)) {
        source = "both";
      } else if (checkList(s, SUB_KEYWORDS)) {
        source = "subject";
      } else {
        source = "snippet";
      }
    }

    return { type, source: source || "unknown" };
  }

  function extractAmount(text) {
    if (!text) return { amount: null, currency: null };

    const dollarMatch = text.match(/\$\s*(\d{1,4}(?:\.\d{1,2})?)/);
    if (dollarMatch) {
      const num = parseFloat(dollarMatch[1]);
      if (!isNaN(num)) {
        return { amount: num, currency: "USD" };
      }
    }
    return { amount: null, currency: null };
  }

  function extractDate(text) {
    if (!text) return null;
    const lower = text.toLowerCase();

    // Month-name dates, e.g. "January 5, 2026" or "Jan 5"
    const monthRegex = new RegExp(
      "\\b(" + MONTH_NAMES.join("|") + ")\\s+\\d{1,2}(?:,\\s*\\d{2,4})?",
      "i"
    );
    const monthMatch = text.match(monthRegex);
    if (monthMatch) {
      const raw = monthMatch[0];
      const d = new Date(raw);
      if (!isNaN(d.getTime())) {
        return d.toISOString();
      }
    }

    // Numeric dates: 01/05/2026, 1/5/26, etc.
    const numericMatch = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
    if (numericMatch) {
      const [_, mm, dd, yyyy] = numericMatch;
      let year = parseInt(yyyy, 10);
      if (year < 100) {
        year += 2000;
      }
      const month = parseInt(mm, 10) - 1;
      const day = parseInt(dd, 10);
      const d = new Date(year, month, day);
      if (!isNaN(d.getTime())) {
        return d.toISOString();
      }
    }

    // ISO-ish fragments like 2026-01-05
    const isoMatch = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      const d = new Date(isoMatch[0]);
      if (!isNaN(d.getTime())) {
        return d.toISOString();
      }
    }

    return null;
  }

  function sanitizeServiceName(senderName, subject) {
    const base = senderName || subject || "";
    const trimmed = base.replace(/\s*\|.*$/, "").replace(/\s*-.+$/, "").trim();
    if (!trimmed) return "Unknown service";
    return trimmed.slice(0, 80);
  }

  function extractSender(row) {
    // Gmail often uses .yX.xY for sender block; inside that .yP or span
    const senderEl =
      row.querySelector(".yX.xY .yP") ||
      row.querySelector(".yW span") ||
      row.querySelector("[email]") ||
      row.querySelector("[data-hovercard-id]");
    if (!senderEl) return "";
    return (senderEl.textContent || "").trim();
  }

  function extractSubject(row) {
    // Classic Gmail: .bog (subject)
    const subjectEl = row.querySelector(".bog") || row.querySelector("span[role='link']");
    if (!subjectEl) return "";
    return (subjectEl.textContent || "").trim();
  }

  function extractSnippet(row) {
    // Classic Gmail: .y2 (snippet)
    const snippetEl = row.querySelector(".y2");
    if (!snippetEl) return "";
    // .y2 often starts with " - " so strip leading dash/space
    return (snippetEl.textContent || "").replace(/^\s*-\s*/, "").trim();
  }

  function extractEmailLink(row) {
    // Find the main link to the thread
    const linkEl =
      row.querySelector("a[href*='#inbox']") ||
      row.querySelector("a[href*='#all']") ||
      row.querySelector("a[href*='#spam']") ||
      row.querySelector("a[href*='#trash']") ||
      row.querySelector("a[href*='#']");
    if (!linkEl) return { url: null, id: null };

    const href = linkEl.href || linkEl.getAttribute("href");
    if (!href) return { url: null, id: null };

    // use full href as stable ID
    return { url: href, id: href };
  }

  function buildTrialObject(row) {
    const sender = extractSender(row);
    const subject = extractSubject(row);
    const snippet = extractSnippet(row);
    const { url, id } = extractEmailLink(row);

    const combinedText = [subject, snippet].filter(Boolean).join(" ");
    const { type, source } = detectTypeAndSource(subject, snippet);

    if (type === "unknown") {
      // Not interesting for our purposes
      return null;
    }

    const { amount, currency } = extractAmount(combinedText);
    const dateIso = extractDate(combinedText);

    const serviceName = sanitizeServiceName(sender, subject);

    return {
      id: id || (subject + "|" + snippet).slice(0, 200),
      serviceName,
      subject,
      snippet,
      sender,
      type,                 // "trial" | "subscription"
      source,               // "subject" | "snippet" | "both" | "unknown"
      nextChargeDate: dateIso,     // ISO string or null
      amount: amount,              // number or null
      currency: currency,          // "USD" or null
      rawEmailUrl: url,
      detectedAt: new Date().toISOString()
    };
  }

  async function waitForRows(timeoutMs = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const rows = findRows();
      if (rows.length > 0) return rows;
      await sleep(300);
    }
    return [];
  }

  function findRows() {
    // Classic Gmail: rows are tr.zA
    let rows = Array.from(document.querySelectorAll("tr.zA"));
    if (rows.length) return rows;

    // Fallback: sometimes Gmail uses div.zA
    rows = Array.from(document.querySelectorAll("div.zA"));
    return rows;
  }

  async function scan() {
    sendProgress("scanner_start", "gmailScanner injected, waiting for rows...");
    const rows = await waitForRows(8000);

    if (!rows.length) {
      sendProgress("scanner_no_rows", "No Gmail rows found in current view.");
      chrome.runtime.sendMessage({
        type: MSG.SCAN_RESULTS,
        trials: []
      });
      return;
    }

    sendProgress("scanner_scanning", `Scanning ${rows.length} rows...`);

    const trials = [];
    for (const row of rows) {
      try {
        const trial = buildTrialObject(row);
        if (trial) {
          trials.push(trial);
        }
      } catch (e) {
        // Ignore row-level errors
        console.error("[FTT] Error building trial object for row", e);
      }
    }

    sendProgress("scanner_done", `Found ${trials.length} suspected trial/sub emails.`);

    try {
      chrome.runtime.sendMessage({
        type: MSG.SCAN_RESULTS,
        trials
      });
    } catch (e) {
      console.error("[FTT] Failed to send scan results", e);
    }
  }

  // Run immediately when injected
  scan().catch(err => {
    console.error("[FTT] scanner failed", err);
    sendProgress("scanner_error", String(err && err.message || err));
  });
})();
