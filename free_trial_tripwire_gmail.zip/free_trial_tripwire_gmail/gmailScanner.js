﻿// gmailScanner.js
// Runs inside the Gmail tab. Scans the current message list view
// and reports suspected trials/subscriptions back to the background script.

(() => {
  const MSG = {
    SCAN_RESULTS: "FTT_SCAN_RESULTS",
    PROGRESS: "FTT_PROGRESS"
  };

  // V2: Added logo service for nicer UI
  const FAVICON_BASE = "https://www.google.com/s2/favicons?sz=64&domain=";

  function sendProgress(stage, details) {
    try {
      chrome.runtime.sendMessage({
        type: MSG.PROGRESS,
        stage,
        details: details || null,
        source: "gmailScanner"
      });
    } catch (e) {
      // fine if nobody is listening
    }
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // ---------------- Detection helpers ----------------

  const TRIAL_KEYWORDS = [
    "free trial",
    "trial period",
    "your trial ends",
    "trial ending",
    "trial expires",
    "trial expiration",
    "start of your trial",
    "trial started",
    "trial will end",
    "trial will renew",
    "trial renews",
    "ends after your trial",
    "trial converts to paid",
    "7-day trial",
    "14-day trial",
    "30-day trial",
    "try it free"
  ];

  const SUB_KEYWORDS = [
    "your subscription",
    "subscription started",
    "subscription is now active",
    "thanks for subscribing",
    "you have subscribed",
    "auto-renew",
    "auto renew",
    "automatic renewal",
    "renewal notice",
    "upcoming charge",
    "upcoming payment",
    "will be charged",
    "will be billed",
    "next bill",
    "next billing date",
    "payment scheduled",
    "renews on",
    "renews at",
    "plan renews",
    "renewing soon",
    "invoice available",
    "receipt for your order"
  ];

  const PERIOD_KEYWORDS = {
    monthly: ["month", "monthly", "/mo", "per month"],
    yearly: ["year", "yearly", "/yr", "per year", "annual", "annually"]
  };

  const NEGATIVE_KEYWORDS = [
    "trial balance",
    "court trial",
    "clinical trial",
    "jury trial",
    "security alert", // often false positives
    "verification code",
    "password reset"
  ];

  const MONTH_WORDS = [
    "january", "jan",
    "february", "feb",
    "march", "mar",
    "april", "apr",
    "may",
    "june", "jun",
    "july", "jul",
    "august", "aug",
    "september", "sept", "sep",
    "october", "oct",
    "november", "nov",
    "december", "dec"
  ];

  function containsAny(text, list) {
    if (!text) return false;
    const lower = text.toLowerCase();
    return list.some(k => lower.includes(k));
  }

  function countMatches(text, list) {
    if (!text) return 0;
    const lower = text.toLowerCase();
    let count = 0;
    for (const k of list) {
      if (lower.includes(k)) count++;
    }
    return count;
  }

  // V2: Detect billing frequency
  function detectPeriod(text) {
    const lower = text.toLowerCase();
    if (PERIOD_KEYWORDS.yearly.some(k => lower.includes(k))) return "yearly";
    if (PERIOD_KEYWORDS.monthly.some(k => lower.includes(k))) return "monthly";
    return "unknown";
  }

  function detectTypeAndSource(subject, snippet) {
    const s = (subject || "").toLowerCase();
    const sn = (snippet || "").toLowerCase();
    const combined = s + " " + sn;

    // Bail out early if this looks like a non-billing "trial"
    if (containsAny(combined, NEGATIVE_KEYWORDS)) {
      return { type: "unknown", source: "unknown", keywordHits: 0 };
    }

    const trialSubjectHits = countMatches(s, TRIAL_KEYWORDS);
    const trialSnippetHits = countMatches(sn, TRIAL_KEYWORDS);
    const subSubjectHits = countMatches(s, SUB_KEYWORDS);
    const subSnippetHits = countMatches(sn, SUB_KEYWORDS);

    const trialHits = trialSubjectHits + trialSnippetHits;
    const subHits = subSubjectHits + subSnippetHits;

    if (trialHits === 0 && subHits === 0) {
      return { type: "unknown", source: "unknown", keywordHits: 0 };
    }

    let type;
    if (trialHits > subHits) {
      type = "trial";
    } else if (subHits > trialHits) {
      type = "subscription";
    } else {
      type = "subscription"; // Tie-break
    }

    let source = "unknown";
    if (type === "trial") {
      if (trialSubjectHits && trialSnippetHits) source = "both";
      else if (trialSubjectHits) source = "subject";
      else if (trialSnippetHits) source = "snippet";
    } else if (type === "subscription") {
      if (subSubjectHits && subSnippetHits) source = "both";
      else if (subSubjectHits) source = "subject";
      else if (subSnippetHits) source = "snippet";
    }

    const keywordHits = type === "trial" ? trialHits : subHits;
    return { type, source: source || "unknown", keywordHits };
  }

  function normalizeCurrencySymbol(symOrCode) {
    if (!symOrCode) return null;
    const v = symOrCode.toLowerCase();
    if (v === "$" || v === "usd") return "USD";
    if (v === "€" || v === "eur") return "EUR";
    if (v === "£" || v === "gbp") return "GBP";
    return null;
  }

  function extractAmount(text) {
    if (!text) return { amount: null, currency: null };

    const lower = text.toLowerCase();

    // Pattern 1: currency then amount  →  $9.99, usd 9.99, € 9,99
    const pattern1 = /\b(\$|usd|eur|€|gbp|£)\s?(\d{1,4}(?:[.,]\d{1,2})?)/i;
    // Pattern 2: amount then currency  →  9.99 usd, 9,99 €
    const pattern2 = /\b(\d{1,4}(?:[.,]\d{1,2})?)\s?(\$|usd|eur|€|gbp|£)\b/i;

    let match = lower.match(pattern1);
    let amountStr = null;
    let currency = null;

    if (match) {
      currency = normalizeCurrencySymbol(match[1]);
      amountStr = match[2];
    } else {
      match = lower.match(pattern2);
      if (match) {
        amountStr = match[1];
        currency = normalizeCurrencySymbol(match[2]);
      }
    }

    if (!match || !amountStr) {
      // Fallback: bare dollar amount like "$9" or "$9.99"
      const bareDollar = lower.match(/\$\s*(\d{1,4}(?:\.\d{1,2})?)/);
      if (bareDollar) {
        amountStr = bareDollar[1];
        currency = "USD";
      } else {
        return { amount: null, currency: null };
      }
    }

    // Normalize comma decimals
    amountStr = amountStr.replace(",", ".");
    const num = parseFloat(amountStr);
    if (isNaN(num)) return { amount: null, currency: null };

    return {
      amount: num,
      currency: currency || null
    };
  }

  function extractAbsoluteDate(text) {
    if (!text) return null;

    // Month-name or abbreviation dates, e.g. "January 5, 2026", "Jan 5"
    const monthRegex = new RegExp(
      "\\b(" + MONTH_WORDS.join("|") + ")\\s+\\d{1,2}(?:,\\s*\\d{2,4})?",
      "i"
    );
    const monthMatch = text.match(monthRegex);
    if (monthMatch) {
      const raw = monthMatch[0];
      // Append current year if missing
      const hasYear = /\d{4}/.test(raw);
      const parseStr = hasYear ? raw : `${raw} ${new Date().getFullYear()}`;
      
      const d = new Date(parseStr);
      if (!isNaN(d.getTime())) {
        return d.toISOString();
      }
    }

    // Numeric dates: 01/05/2026, 1/5/26, etc.
    const numericMatch = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
    if (numericMatch) {
      const [_, mm, dd, yyyy] = numericMatch;
      let year = parseInt(yyyy, 10);
      if (year < 100) {
        year += 2000;
      }
      const month = parseInt(mm, 10) - 1;
      const day = parseInt(dd, 10);
      const d = new Date(year, month, day);
      if (!isNaN(d.getTime())) {
        return d.toISOString();
      }
    }

    // ISO-like dates: 2026-01-05
    const isoMatch = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      const d = new Date(isoMatch[0]);
      if (!isNaN(d.getTime())) {
        return d.toISOString();
      }
    }

    return null;
  }

  function extractRelativeDate(text) {
    if (!text) return null;
    const lower = text.toLowerCase();
    const now = new Date();

    const makeIso = (d) => {
      if (!d || isNaN(d.getTime())) return null;
      return d.toISOString();
    };

    if (lower.includes("today")) {
      return makeIso(new Date());
    }

    if (lower.includes("tomorrow")) {
      const d = new Date();
      d.setDate(d.getDate() + 1);
      return makeIso(d);
    }

    if (lower.includes("next week")) {
      const d = new Date();
      d.setDate(d.getDate() + 7);
      return makeIso(d);
    }

    if (lower.includes("next month")) {
      const d = new Date();
      d.setMonth(d.getMonth() + 1);
      return makeIso(d);
    }

    // "in X days"
    const inDays = lower.match(/\bin\s+(\d{1,2})\s+day/);
    if (inDays) {
      const n = parseInt(inDays[1], 10);
      if (!isNaN(n)) {
        const d = new Date();
        d.setDate(d.getDate() + n);
        return makeIso(d);
      }
    }

    // "X-day trial" -> assume starts today, ends in X days
    const xDayTrial = lower.match(/(\d{1,2})-day\s+trial/);
    if (xDayTrial) {
        const n = parseInt(xDayTrial[1], 10);
        if(!isNaN(n)) {
            const d = new Date();
            d.setDate(d.getDate() + n);
            return makeIso(d);
        }
    }

    return null;
  }

  function extractDate(text) {
    if (!text) return null;
    const abs = extractAbsoluteDate(text);
    if (abs) return abs;

    const rel = extractRelativeDate(text);
    if (rel) return rel;

    return null;
  }

  function sanitizeServiceName(senderName, subject) {
    const base = senderName || subject || "";
    // Remove "Action Required:", "Notification from", etc.
    const clean = base
      .replace(/^(notification from|alert:|receipt for|invoice from)\s+/i, "")
      .replace(/\s*\|.*$/, "")
      .replace(/\s*-.+$/, "")
      .trim();
    
    if (!clean) return "Unknown Service";
    // If it's too long, it's likely a subject line, not a service name. 
    // Truncate cleanly.
    return clean.length > 30 ? clean.slice(0, 30) + "..." : clean;
  }

  // V2: Better sender extraction
  function extractSenderInfo(row) {
    // Gmail often uses .yX.xY for sender block; inside that .yP or span
    // The "email" attribute is usually hidden in the "yP" element
    const senderEl =
      row.querySelector("[email]") ||
      row.querySelector(".yP");

    let name = "";
    let email = "";
    let domain = "";

    if (senderEl) {
        name = senderEl.getAttribute("name") || senderEl.textContent || "";
        email = senderEl.getAttribute("email") || ""; 
    }

    // Fallback if we have name but no email (sometimes happens in span)
    if (!email && name.includes("@")) {
        // Try to regex an email out of the name
        const match = name.match(/<([^>]+)>/) || name.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/);
        if (match) email = match[1];
    }

    if (email) {
        const parts = email.split("@");
        if (parts.length === 2) domain = parts[1];
    }

    return { name: name.trim(), email, domain };
  }

  function extractSubject(row) {
    // Classic Gmail: .bog (subject)
    const subjectEl =
      row.querySelector(".bog") ||
      row.querySelector("span[role='link']");
    if (!subjectEl) return "";
    return (subjectEl.textContent || "").trim();
  }

  function extractSnippet(row) {
    // Classic Gmail: .y2 (snippet)
    const snippetEl = row.querySelector(".y2");
    if (!snippetEl) return "";
    return (snippetEl.textContent || "")
      .replace(/^\s*-\s*/, "")
      .trim();
  }

  function extractEmailLink(row) {
    // Find the main link to the thread
    const linkEl =
      row.querySelector("a[href*='#inbox']") ||
      row.querySelector("a[href*='#all']") ||
      row.querySelector("a[href*='#spam']") ||
      row.querySelector("a[href*='#trash']") ||
      row.querySelector("a[href*='#']");

    if (!linkEl) return { url: null, id: null, threadId: null, rawUrl: null };

    const rawHref = linkEl.getAttribute("href") || linkEl.href || "";
    if (!rawHref) {
      return { url: null, id: null, threadId: null, rawUrl: null };
    }

    // Normalize to an absolute URL
    let absoluteUrl;
    try {
      absoluteUrl = new URL(rawHref, window.location.origin).toString();
    } catch {
      absoluteUrl = rawHref;
    }

    let threadId = null;
    const hashIndex = absoluteUrl.indexOf("#");
    if (hashIndex !== -1) {
      const hash = absoluteUrl.slice(hashIndex + 1); // e.g. inbox/17d2...
      const parts = hash.split("/");
      if (parts.length >= 2) {
        threadId = parts[1];
      }
    }

    let threadUrl = absoluteUrl;
    if (threadId) {
      // Canonical inbox URL for this thread (assume account 0)
      threadUrl = `https://mail.google.com/mail/u/0/#inbox/${threadId}`;
    }

    return {
      url: threadUrl,
      id: threadId || absoluteUrl,
      threadId: threadId || null,
      rawUrl: absoluteUrl
    };
  }

  function computeConfidence(info, amount, dateIso) {
    let c = 0;
    if (info.type !== "unknown") c += 0.4;
    if (info.keywordHits >= 2) c += 0.2;
    if (info.source === "both") c += 0.1;
    if (amount != null) c += 0.15;
    if (dateIso) c += 0.15;
    if (c > 1) c = 1;
    return c;
  }

  function buildTrialObject(row) {
    const senderInfo = extractSenderInfo(row);
    const subject = extractSubject(row);
    const snippet = extractSnippet(row);
    const linkInfo = extractEmailLink(row);

    const combinedText = [subject, snippet].filter(Boolean).join(" ");
    const detectInfo = detectTypeAndSource(subject, snippet);

    if (detectInfo.type === "unknown") {
      return null;
    }

    const { amount, currency } = extractAmount(combinedText);
    const dateIso = extractDate(combinedText);
    const period = detectPeriod(combinedText);

    const serviceName = sanitizeServiceName(senderInfo.name, subject);
    const confidence = computeConfidence(detectInfo, amount, dateIso);

    const nowIso = new Date().toISOString();
    
    // V2: Construct logo URL
    let logoUrl = null;
    if (senderInfo.domain) {
        logoUrl = FAVICON_BASE + senderInfo.domain;
    }

    return {
      id: linkInfo.id || (subject + "|" + snippet).slice(0, 200),
      serviceName,
      subject,
      snippet,
      sender: senderInfo.name,
      senderEmail: senderInfo.email, // V2
      senderDomain: senderInfo.domain, // V2
      logoUrl: logoUrl, // V2
      type: detectInfo.type,        // "trial" | "subscription"
      source: detectInfo.source,    // "subject" | "snippet" | "both"
      nextChargeDate: dateIso,      
      amount: amount,              
      currency: currency,          
      period: period,               // V2: "monthly", "yearly", "unknown"
      rawEmailUrl: linkInfo.rawUrl,
      threadUrl: linkInfo.url,
      threadId: linkInfo.threadId,
      confidence,                   
      detectedAt: nowIso,
      scannerVersion: "2.0.0"
    };
  }

  async function waitForRows(timeoutMs = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const rows = findRows();
      if (rows.length > 0) return rows;
      await sleep(300);
    }
    return [];
  }

  function findRows() {
    // Classic Gmail: rows are tr.zA
    let rows = Array.from(document.querySelectorAll("tr.zA"));
    if (rows.length) return rows;
    // Fallback: sometimes Gmail uses div.zA
    rows = Array.from(document.querySelectorAll("div.zA"));
    return rows;
  }

  async function scan() {
    sendProgress("scanner_start", "gmailScanner injected, waiting for rows...");
    const rows = await waitForRows(8000);

    if (!rows.length) {
      sendProgress("scanner_no_rows", "No Gmail rows found in current view.");
      chrome.runtime.sendMessage({
        type: MSG.SCAN_RESULTS,
        trials: []
      });
      return;
    }

    sendProgress("scanner_scanning", `Scanning ${rows.length} rows...`);

    const trials = [];
    for (const row of rows) {
      try {
        const trial = buildTrialObject(row);
        if (trial) {
          trials.push(trial);
        }
      } catch (e) {
        console.error("[FTT] Error building trial object for row", e);
      }
    }

    sendProgress(
      "scanner_done",
      `Found ${trials.length} suspected trial/sub emails.`
    );

    try {
      chrome.runtime.sendMessage({
        type: MSG.SCAN_RESULTS,
        trials
      });
    } catch (e) {
      console.error("[FTT] Failed to send scan results", e);
    }
  }

  // Run immediately when injected
  scan().catch(err => {
    console.error("[FTT] scanner failed", err);
    sendProgress("scanner_error", String((err && err.message) || err));
  });
})();