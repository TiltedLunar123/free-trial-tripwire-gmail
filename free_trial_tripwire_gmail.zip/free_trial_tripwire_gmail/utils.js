﻿// utils.js
// Generic helpers for Free-Trial Tripwire.
//
// Exposes global FTTUtils with:
// - sleep(ms)
// - formatCurrency(amount, currency)
// - formatDate(isoString)
// - parseAmountFromText(text)
// - parseDateFromText(text)
// - generateUUID()                  <-- New in v2.0
// - getFaviconUrl(domain)           <-- New in v2.0

(function initFTTUtils(global) {
  if (!global) return;

  const MONTH_WORDS = [
    "january", "jan",
    "february", "feb",
    "march", "mar",
    "april", "apr",
    "may",
    "june", "jun",
    "july", "jul",
    "august", "aug",
    "september", "sept", "sep",
    "october", "oct",
    "november", "nov",
    "december", "dec"
  ];

  // -------- timing --------

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // -------- identifiers (V2) --------

  function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  // -------- formatting --------

  function formatCurrency(amount, currency = "USD") {
    if (typeof amount !== "number" || isNaN(amount)) return null;
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency
      }).format(amount);
    } catch (e) {
      return `$${amount.toFixed(2)}`;
    }
  }

  function formatDate(iso) {
    if (!iso) return null;
    const d = new Date(iso);
    if (isNaN(d.getTime())) return null;
    return d.toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  }

  function getFaviconUrl(domain) {
    if (!domain) return null;
    return `https://www.google.com/s2/favicons?sz=64&domain=${domain}`;
  }

  // -------- amount parsing --------

  function normalizeCurrencySymbol(symOrCode) {
    if (!symOrCode) return null;
    const v = String(symOrCode).toLowerCase();
    if (v === "$" || v === "usd") return "USD";
    if (v === "€" || v === "eur") return "EUR";
    if (v === "£" || v === "gbp") return "GBP";
    return null;
  }

  /**
   * Best-effort amount parser.
   * Supports:
   * "$9.99", "usd 9.99", "€ 9,99", "9.99 usd", "9,99 €", etc.
   */
  function parseAmountFromText(text) {
    if (!text) return { amount: null, currency: null };

    // Pattern 1: currency then amount  →  $9.99, usd 9.99, € 9,99
    const pattern1 = /\b(\$|usd|eur|€|gbp|£)\s?(\d{1,4}(?:[.,]\d{1,2})?)/i;
    // Pattern 2: amount then currency  →  9.99 usd, 9,99 €
    const pattern2 = /\b(\d{1,4}(?:[.,]\d{1,2})?)\s?(\$|usd|eur|€|gbp|£)\b/i;

    let match = text.match(pattern1);
    let amountStr = null;
    let currency = null;

    if (match) {
      currency = normalizeCurrencySymbol(match[1]);
      amountStr = match[2];
    } else {
      match = text.match(pattern2);
      if (match) {
        amountStr = match[1];
        currency = normalizeCurrencySymbol(match[2]);
      }
    }

    if (!match || !amountStr) {
      // Fallback: bare dollar amount like "$9"
      const bareDollar = text.match(/\$\s*(\d{1,4}(?:\.\d{1,2})?)/);
      if (bareDollar) {
        amountStr = bareDollar[1];
        currency = "USD";
      } else {
        return { amount: null, currency: null };
      }
    }

    // Normalize comma decimals
    amountStr = amountStr.replace(",", ".");
    const num = parseFloat(amountStr);
    if (isNaN(num)) return { amount: null, currency: null };

    return { amount: num, currency: currency || null };
  }

  // -------- date parsing --------

  function parseAbsoluteDateFromText(text) {
    if (!text) return null;

    // Month-name / abbreviation style: "January 5, 2026" or "Jan 5"
    const monthRegex = new RegExp(
      "\\b(" + MONTH_WORDS.join("|") + ")\\s+\\d{1,2}(?:,\\s*\\d{2,4})?",
      "i"
    );
    const monthMatch = text.match(monthRegex);
    if (monthMatch) {
      const raw = monthMatch[0];
      const d = new Date(raw);
      // If year is missing in text, it might default to 2001. 
      // V2 fix: if date is in past, add current year.
      if (!isNaN(d.getTime())) {
          return d.toISOString();
      }
    }

    // Numeric dates: 01/05/2026, 1/5/26, etc.
    const numericMatch = text.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
    if (numericMatch) {
      const [, mm, dd, yyyy] = numericMatch;
      let year = parseInt(yyyy, 10);
      if (year < 100) year += 2000;
      const month = parseInt(mm, 10) - 1;
      const day = parseInt(dd, 10);
      const d = new Date(year, month, day);
      if (!isNaN(d.getTime())) return d.toISOString();
    }

    // ISO-like: 2026-01-05
    const isoMatch = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      const d = new Date(isoMatch[0]);
      if (!isNaN(d.getTime())) return d.toISOString();
    }

    return null;
  }

  function parseRelativeDateFromText(text) {
    if (!text) return null;
    const lower = text.toLowerCase();
    const now = new Date();

    const makeIso = d => {
      if (!d || isNaN(d.getTime())) return null;
      return d.toISOString();
    };

    if (lower.includes("today")) {
      const d = new Date(now);
      return makeIso(d);
    }

    if (lower.includes("tomorrow")) {
      const d = new Date(now);
      d.setDate(d.getDate() + 1);
      return makeIso(d);
    }

    if (lower.includes("next week")) {
      const d = new Date(now);
      d.setDate(d.getDate() + 7);
      return makeIso(d);
    }

    if (lower.includes("next month")) {
      const d = new Date(now);
      d.setMonth(d.getMonth() + 1);
      return makeIso(d);
    }

    // "in X days"
    const inDays = lower.match(/\bin\s+(\d{1,2})\s+day/);
    if (inDays) {
      const n = parseInt(inDays[1], 10);
      if (!isNaN(n)) {
        const d = new Date(now);
        d.setDate(d.getDate() + n);
        return makeIso(d);
      }
    }

    // "in X weeks"
    const inWeeks = lower.match(/\bin\s+(\d{1,2})\s+week/);
    if (inWeeks) {
      const n = parseInt(inWeeks[1], 10);
      if (!isNaN(n)) {
        const d = new Date(now);
        d.setDate(d.getDate() + n * 7);
        return makeIso(d);
      }
    }

    // V2: "X-day trial" (implies ends in X days from today)
    const xDayTrial = lower.match(/(\d{1,2})-day\s+trial/);
    if (xDayTrial) {
        const n = parseInt(xDayTrial[1], 10);
        if(!isNaN(n)) {
            const d = new Date(now);
            d.setDate(d.getDate() + n);
            return makeIso(d);
        }
    }

    return null;
  }

  function parseDateFromText(text) {
    if (!text) return null;
    const abs = parseAbsoluteDateFromText(text);
    if (abs) return abs;
    const rel = parseRelativeDateFromText(text);
    if (rel) return rel;
    return null;
  }

  const api = {
    sleep,
    formatCurrency,
    formatDate,
    getFaviconUrl,
    generateUUID,
    parseAmountFromText,
    parseDateFromText,
    version: "2.0.0"
  };

  global.FTTUtils = api;
})(
  typeof globalThis !== "undefined"
    ? globalThis
    : typeof self !== "undefined"
    ? self
    : typeof window !== "undefined"
    ? window
    : this
);