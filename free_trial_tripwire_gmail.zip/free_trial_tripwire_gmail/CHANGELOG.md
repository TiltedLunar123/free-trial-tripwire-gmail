# Changelog

All notable changes to this project will be documented in this file.

## [2.0.0] - 2025-12-03

### Added
- **Direct Google Calendar Integration**:
  - Added `chrome.identity` OAuth2 flow to authenticate users safely.
  - New "Add to Calendar" feature pushes trial dates directly to the user's primary Google Calendar.
- **Interactive Dashboard Features**:
  - **Manual Entry**: Users can now manually add trials (for apps signed up outside of email).
  - **Trial Deletion**: Added ability to remove specific trials from the dashboard.
- **UUID Generation**: Implemented unique ID generation for manually added trials to prevent collisions.

### Changed
- **Background Service Architecture**:
  - Updated `background.js` message routing to handle CRUD operations (`ADD_MANUAL_TRIAL`, `DELETE_TRIAL`).
  - Refined storage logic to differentiate between 'scanned' and 'manual' trial sources.
- **Permission Scopes**: Expanded manifest requirements to include `identity` for Calendar API access (pending manifest update).

---

## [0.2.0] - 2025-11-30

### Changed
- Hardened scan flow in `background.js`:
  - Added single-scan “busy” lock to avoid overlapping scans.
  - Added Gmail tab detection with load timeout and stricter tab ID checks.
  - Made progress / error reporting more defensive and explicit.
  - Enriched stored trial records with `firstSeenAt` and `lastSeenAt` metadata.
- Improved error handling around `chrome.tabs`, `chrome.scripting`, and `chrome.storage` calls.

### Fixed
- Cases where:
  - A Gmail tab existed but had no valid `id`.
  - The extension could hang waiting for Gmail to finish loading.
  - Storage operations could fail silently and leave the popup in a bad state.

---

## [0.1.0] - 2025-11-29

### Added
- Initial scaffold for **Free-Trial Tripwire for Gmail**:
  - Basic popup, background, and Gmail scanner wiring.
  - Local storage of detected trials keyed by `id`.
  - Simple progress messages from background → popup during scans.