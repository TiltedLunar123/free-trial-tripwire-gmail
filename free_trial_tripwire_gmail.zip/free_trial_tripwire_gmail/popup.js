﻿// popup.js - Version 2.0.0

const MSG = {
  START_SCAN: "FTT_START_SCAN",
  SCAN_RESULTS: "FTT_SCAN_RESULTS",
  GET_TRIALS: "FTT_GET_TRIALS",
  TRIALS_UPDATED: "FTT_TRIALS_UPDATED",
  PROGRESS: "FTT_PROGRESS",
  // V2 Commands
  ADD_TO_CALENDAR: "FTT_ADD_TO_CALENDAR",
  ADD_MANUAL_TRIAL: "FTT_ADD_MANUAL_TRIAL",
  DELETE_TRIAL: "FTT_DELETE_TRIAL"
};

let allTrials = [];
let currentFilter = "all";
let lastScanAt = null;

// ------- DOM Helpers -------

function $(id) {
  return document.getElementById(id);
}

function formatCurrency(amount, currency = "USD") {
  if (typeof amount !== "number" || isNaN(amount)) return "$0.00";
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency
    }).format(amount);
  } catch {
    return `$${amount.toFixed(2)}`;
  }
}

function formatDate(iso) {
  if (!iso) return "Unknown Date";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "Unknown Date";
  return d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

// ------- Status UI -------

function setStatus(mode, text) {
  const dot = $("statusDot");
  const label = $("statusLabel");
  const sub = $("statusText");

  if (!dot || !label) return;

  // Reset classes
  dot.className = "status-dot";

  if (mode === "idle") {
    dot.classList.add("status-dot--idle");
    label.textContent = "Idle";
    if(sub) sub.textContent = text || "Ready to scan";
  } else if (mode === "scanning") {
    label.textContent = "Scanning";
    if(sub) sub.textContent = text || "Scanning inbox...";
  } else if (mode === "error") {
    dot.classList.add("status-dot--error");
    label.textContent = "Error";
    if(sub) sub.textContent = text || "Something went wrong";
  } else if (mode === "done") {
    label.textContent = "Done";
    if(sub) sub.textContent = text || "Scan complete";
  }
}

// ------- Modal Logic (Manual Add) -------

function toggleModal(show) {
  const modal = $("manualModal");
  if (show) modal.classList.add("active");
  else modal.classList.remove("active");
  
  // Clear inputs on close
  if (!show) {
    $("inpService").value = "";
    $("inpCost").value = "";
    $("inpDate").value = "";
  }
}

async function saveManualTrial() {
  const service = $("inpService").value.trim();
  const costStr = $("inpCost").value;
  const dateStr = $("inpDate").value;

  if (!service) {
    alert("Please enter a service name.");
    return;
  }

  const cost = parseFloat(costStr);
  const trialData = {
    serviceName: service,
    amount: isNaN(cost) ? 0 : cost,
    currency: "USD",
    nextChargeDate: dateStr ? new Date(dateStr).toISOString() : null,
    type: "subscription", // Default manually added as sub
    source: "manual",
    confidence: 1.0,
    detectedAt: new Date().toISOString()
  };

  try {
    await sendMessage({ type: MSG.ADD_MANUAL_TRIAL, trial: trialData });
    toggleModal(false);
    // Refresh happens automatically via listener
  } catch (e) {
    alert("Failed to save: " + e.message);
  }
}

// ------- Action Logic (Calendar & Delete) -------

async function handleAddToCalendar(trial, btnElement) {
  if (!trial.nextChargeDate) {
    alert("No renewal date detected. Please check the email or edit manually.");
    return;
  }

  const originalText = btnElement.innerHTML;
  btnElement.innerHTML = "⏳"; 
  btnElement.disabled = true;

  try {
    const res = await sendMessage({ 
      type: MSG.ADD_TO_CALENDAR, 
      trial: trial, 
      reminderHours: 24 
    });

    if (res && res.ok && res.link) {
      // Open the event in a new tab
      window.open(res.link, "_blank");
      btnElement.innerHTML = "✓"; // Success state
    } else {
      throw new Error(res.error || "Unknown error");
    }
  } catch (e) {
    console.error(e);
    alert("Calendar Error: " + e.message + "\n\nMake sure you granted permission.");
    btnElement.innerHTML = originalText;
    btnElement.disabled = false;
  }
}

async function handleDelete(id) {
  if (!confirm("Remove this trial from your dashboard?")) return;
  try {
    await sendMessage({ type: MSG.DELETE_TRIAL, id });
  } catch (e) {
    console.error(e);
  }
}

// ------- Rendering -------

function applyFilter(trials) {
  if (currentFilter === "all") return trials;
  return trials.filter(t => t.type === currentFilter);
}

function renderSummary(trials) {
  const countEl = $("trialCount");
  const costEl = $("totalCost");

  const filtered = applyFilter(trials);
  
  // Count
  if (countEl) countEl.textContent = `${filtered.length} detected`;

  // Cost Calc
  let total = 0;
  for (const t of filtered) {
    if (typeof t.amount === "number" && !isNaN(t.amount)) {
      // Simple logic: if period is yearly, divide by 12? 
      // For V2 MVP, let's just sum the face value detected for simplicity, 
      // or check 'period' property.
      let amount = t.amount;
      if (t.period === "yearly" || t.period === "annual") {
        amount = amount / 12; // Amortize for monthly view
      }
      total += amount;
    }
  }
  
  if (costEl) costEl.textContent = formatCurrency(total, "USD");
}

function renderTable(trials) {
  const list = $("resultsList");
  if (!list) return;

  // Clear existing
  list.innerHTML = "";

  const filtered = applyFilter(trials);

  if (filtered.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-strong">No items found.</div>
        <div>${allTrials.length > 0 ? "Try changing filters." : "Scan your inbox or add one manually."}</div>
      </div>
    `;
    return;
  }

  filtered.forEach(trial => {
    // 1. Create Row
    const row = document.createElement("div");
    row.className = "table-row";

    // 2. Service Column (Logo + Name)
    const colService = document.createElement("div");
    colService.className = "cell-service";
    
    // Logo
    const img = document.createElement("img");
    img.className = "service-icon";
    img.src = trial.logoUrl || "assets/icon16.png"; 
    img.onerror = () => { img.src = "assets/icon16.png"; }; // Fallback
    
    // Name + Meta
    const divName = document.createElement("div");
    divName.style.overflow = "hidden";
    
    const nameSpan = document.createElement("span");
    nameSpan.className = "service-name";
    nameSpan.textContent = trial.serviceName || "Unknown";
    
    const metaSpan = document.createElement("div");
    metaSpan.className = "meta";
    metaSpan.textContent = trial.sender || "Manual Entry";

    divName.appendChild(nameSpan);
    divName.appendChild(metaSpan);
    
    colService.appendChild(img);
    colService.appendChild(divName);

    // 3. Type Column
    const colType = document.createElement("div");
    const badge = document.createElement("span");
    badge.className = `badge-type badge-type--${trial.type === 'trial' ? 'trial' : 'sub'}`;
    badge.textContent = trial.type === 'trial' ? 'Trial' : 'Sub';
    colType.appendChild(badge);

    // 4. Date Column
    const colDate = document.createElement("div");
    colDate.className = "cell-date";
    colDate.textContent = formatDate(trial.nextChargeDate);

    // 5. Cost + Actions Column
    const colAmount = document.createElement("div");
    colAmount.className = "cell-amount";
    
    // Cost Text
    const costText = document.createElement("span");
    costText.textContent = formatCurrency(trial.amount, trial.currency);
    colAmount.appendChild(costText);

    // Actions Wrapper
    const actionsDiv = document.createElement("div");
    actionsDiv.className = "action-buttons";

    // Calendar Button
    if (trial.nextChargeDate) {
        const btnCal = document.createElement("button");
        btnCal.className = "btn-action calendar";
        btnCal.title = "Add to Google Calendar";
        btnCal.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`;
        btnCal.onclick = () => handleAddToCalendar(trial, btnCal);
        actionsDiv.appendChild(btnCal);
    }

    // Open Email Button
    if (trial.threadUrl) {
        const btnOpen = document.createElement("button");
        btnOpen.className = "btn-action";
        btnOpen.title = "Open Email";
        btnOpen.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>`;
        btnOpen.onclick = () => chrome.tabs.create({ url: trial.threadUrl });
        actionsDiv.appendChild(btnOpen);
    }

    // Delete Button
    const btnDel = document.createElement("button");
    btnDel.className = "btn-action delete";
    btnDel.title = "Remove from Dashboard";
    btnDel.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`;
    btnDel.onclick = () => handleDelete(trial.id);
    actionsDiv.appendChild(btnDel);

    colAmount.appendChild(actionsDiv);

    // Append All
    row.appendChild(colService);
    row.appendChild(colType);
    row.appendChild(colDate);
    row.appendChild(colAmount);

    list.appendChild(row);
  });
}

function renderAll() {
  renderSummary(allTrials);
  renderTable(allTrials);
}

// ------- Communication -------

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(message, response => {
        const err = chrome.runtime.lastError;
        if (err) return reject(err);
        resolve(response);
      });
    } catch (e) {
      reject(e);
    }
  });
}

async function requestInitialTrials() {
  try {
    const res = await sendMessage({ type: MSG.GET_TRIALS });
    if (res && res.ok) {
      allTrials = res.trials || [];
      lastScanAt = res.lastScanAt;
      renderAll();
    }
  } catch (e) {
    console.error("Init load failed", e);
  }
}

async function startScan() {
  setStatus("scanning");
  const btn = $("btnScan");
  if (btn) btn.disabled = true;

  try {
    const res = await sendMessage({ type: MSG.START_SCAN });
    if (!res || !res.ok) {
        if(res && res.busy) setStatus("scanning", "Already running...");
        else setStatus("error", res ? res.error : "Unknown error");
    }
  } catch (e) {
    setStatus("error", e.message);
  } finally {
    if (btn) setTimeout(() => btn.disabled = false, 1000);
  }
}

// ------- Event Listeners -------

document.addEventListener("DOMContentLoaded", () => {
  setStatus("idle");

  // 1. Buttons
  const btnScan = $("btnScan");
  if (btnScan) btnScan.addEventListener("click", startScan);

  const btnAddManual = $("btnAddManual");
  if (btnAddManual) btnAddManual.addEventListener("click", () => toggleModal(true));

  const btnCloseModal = $("btnCloseModal");
  if (btnCloseModal) btnCloseModal.addEventListener("click", () => toggleModal(false));

  const btnSaveManual = $("btnSaveManual");
  if (btnSaveManual) btnSaveManual.addEventListener("click", saveManualTrial);

  // 2. Filters
  const filterContainer = $("filterContainer");
  if (filterContainer) {
    filterContainer.addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      
      // UI Toggle
      document.querySelectorAll(".chip").forEach(c => c.classList.remove("chip--active"));
      chip.classList.add("chip--active");

      // Logic
      currentFilter = chip.dataset.filter;
      renderAll();
    });
  }

  // 3. Messages
  chrome.runtime.onMessage.addListener((message) => {
    if (!message || !message.type) return;

    if (message.type === MSG.PROGRESS) {
      if (message.stage === "scanner_done") setStatus("done");
      else if (message.stage === "error") setStatus("error", message.details);
      else setStatus("scanning", message.details);
    }

    if (message.type === MSG.TRIALS_UPDATED) {
      allTrials = message.trials || [];
      lastScanAt = message.lastScanAt;
      renderAll();
      
      // If we were scanning, revert to idle after a moment
      const lbl = $("statusLabel");
      if(lbl && lbl.textContent === "Done") {
          setTimeout(() => setStatus("idle"), 2000);
      }
    }
  });

  // 4. Initial Load
  requestInitialTrials();
});