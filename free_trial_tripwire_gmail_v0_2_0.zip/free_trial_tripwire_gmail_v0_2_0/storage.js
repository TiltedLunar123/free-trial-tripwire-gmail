﻿// storage.js
// Small helper around chrome.storage.local for Free-Trial Tripwire.
//
// Exposes a global FTTStorage object with async helpers:
// - FTTStorage.getAllTrials()
// - FTTStorage.saveTrials(trialsArray)
// - FTTStorage.mergeTrials(trialsArray)
// - FTTStorage.clearTrials()
// - FTTStorage.getLastScanAt()
// - FTTStorage.setLastScanAt(timestampMs)
//
// Trials are stored under "trialsById" as:
// { [id]: { ...trial, firstSeenAt, lastSeenAt } }

(function initFTTStorage(global) {
  try {
    if (!global) return;

    const KEY_TRIALS = "trialsById";
    const KEY_LAST_SCAN = "lastScanAt";

    function getStore() {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
        throw new Error("chrome.storage.local is not available");
      }
      return chrome.storage.local;
    }

    function storageGet(keys) {
      const store = getStore();
      return new Promise((resolve, reject) => {
        store.get(keys, result => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) {
            reject(err);
          } else {
            resolve(result || {});
          }
        });
      });
    }

    function storageSet(items) {
      const store = getStore();
      return new Promise((resolve, reject) => {
        store.set(items, () => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
    }

    function storageRemove(keys) {
      const store = getStore();
      return new Promise((resolve, reject) => {
        store.remove(keys, () => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
    }

    // ---------- Public API ----------

    async function getAllTrials() {
      const data = await storageGet([KEY_TRIALS]);
      const trialsById = data[KEY_TRIALS] || {};
      return Object.values(trialsById);
    }

    async function saveTrials(trialsArray) {
      const map = {};
      const nowIso = new Date().toISOString();

      if (Array.isArray(trialsArray)) {
        for (const t of trialsArray) {
          if (!t || !t.id) continue;
          const copy = { ...t };
          copy.firstSeenAt = copy.firstSeenAt || nowIso;
          copy.lastSeenAt = nowIso;
          map[t.id] = copy;
        }
      }

      await storageSet({ [KEY_TRIALS]: map });
    }

    async function mergeTrials(trialsArray) {
      if (!Array.isArray(trialsArray) || trialsArray.length === 0) return;

      const nowIso = new Date().toISOString();
      const data = await storageGet([KEY_TRIALS]);
      const trialsById = data[KEY_TRIALS] || {};

      for (const t of trialsArray) {
        if (!t || !t.id) continue;

        const existing = trialsById[t.id] || {};
        const merged = Object.assign({}, existing, t);

        // Track first/last seen timestamps
        merged.firstSeenAt = existing.firstSeenAt || t.firstSeenAt || nowIso;
        merged.lastSeenAt = nowIso;

        trialsById[t.id] = merged;
      }

      await storageSet({ [KEY_TRIALS]: trialsById });
    }

    async function clearTrials() {
      await storageRemove([KEY_TRIALS]);
    }

    async function getLastScanAt() {
      const data = await storageGet([KEY_LAST_SCAN]);
      return data[KEY_LAST_SCAN] || null;
    }

    async function setLastScanAt(timestampMs) {
      await storageSet({ [KEY_LAST_SCAN]: timestampMs || Date.now() });
    }

    const api = {
      getAllTrials,
      saveTrials,
      mergeTrials,
      clearTrials,
      getLastScanAt,
      setLastScanAt,
      version: "0.2.0"
    };

    // Attach to global so background.js / popup.js / content scripts can use it
    global.FTTStorage = api;
  } catch (e) {
    // If anything goes wrong, fail silently; the extension can still use
    // its own inline storage helpers.
    // eslint-disable-next-line no-console
    console.warn("[FTT storage] Failed to initialize storage helper:", e);
  }
})(
  typeof globalThis !== "undefined"
    ? globalThis
    : typeof self !== "undefined"
    ? self
    : typeof window !== "undefined"
    ? window
    : this
);
