﻿// popup.js

const MSG = {
  START_SCAN: "FTT_START_SCAN",
  SCAN_RESULTS: "FTT_SCAN_RESULTS",
  GET_TRIALS: "FTT_GET_TRIALS",
  TRIALS_UPDATED: "FTT_TRIALS_UPDATED",
  PROGRESS: "FTT_PROGRESS"
};

let allTrials = [];
let currentFilter = "all";
let lastScanAt = null;

// ------- DOM helpers -------

function $(id) {
  return document.getElementById(id);
}

function formatCurrency(amount, currency = "USD") {
  if (typeof amount !== "number" || isNaN(amount)) return null;
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency
    }).format(amount);
  } catch {
    return `$${amount.toFixed(2)}`;
  }
}

function formatDate(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d.getTime())) return null;
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}

function formatLastScan(ts) {
  if (!ts) return "Last scan: never";
  const d = new Date(ts);
  if (isNaN(d.getTime())) return "Last scan: unknown";

  const now = Date.now();
  const diffMs = now - d.getTime();
  const diffMin = Math.round(diffMs / 60000);

  if (diffMin < 1) return "Last scan: just now";
  if (diffMin === 1) return "Last scan: 1 min ago";
  if (diffMin < 60) return `Last scan: ${diffMin} mins ago`;

  const diffHours = Math.round(diffMin / 60);
  if (diffHours === 1) return "Last scan: 1 hr ago";
  if (diffHours < 24) return `Last scan: ${diffHours} hrs ago`;

  return "Last scan: " + d.toLocaleString();
}

// ------- Status UI -------

function setStatus(mode, text) {
  const pill = $("status-pill");
  const dot = $("status-dot");
  const textEl = $("status-text");
  if (!pill || !dot || !textEl) return;

  dot.classList.remove("status-dot--idle");
  dot.classList.remove("status-dot--error");

  if (mode === "idle") {
    dot.classList.add("status-dot--idle");
    textEl.textContent = text || "Idle";
  } else if (mode === "scanning") {
    textEl.textContent = text || "Scanning…";
  } else if (mode === "error") {
    dot.classList.add("status-dot--error");
    textEl.textContent = text || "Error";
  } else if (mode === "done") {
    textEl.textContent = text || "Done";
  }
}

// ------- ICS / reminder -------

function buildIcsContent(trial) {
  if (!trial.nextChargeDate) return null;

  const chargeDate = new Date(trial.nextChargeDate);
  if (isNaN(chargeDate.getTime())) return null;

  const start = new Date(chargeDate.getTime());
  start.setDate(start.getDate() - 1);
  start.setHours(9, 0, 0, 0);

  const end = new Date(start.getTime() + 30 * 60 * 1000);

  function toIcsDate(d) {
    const pad = n => String(n).padStart(2, "0");
    // treat as local; ICS with "Z" is fine for most calendars
    return (
      d.getFullYear().toString() +
      pad(d.getMonth() + 1) +
      pad(d.getDate()) +
      "T" +
      pad(d.getHours()) +
      pad(d.getMinutes()) +
      pad(d.getSeconds()) +
      "Z"
    );
  }

  const uid = (trial.id || trial.serviceName || "trial") + "-" + Date.now();

  const summary = `Cancel ${trial.serviceName || "subscription"}`;
  const descriptionLines = [];
  if (typeof trial.amount === "number") {
    const amt = formatCurrency(trial.amount, trial.currency || "USD");
    descriptionLines.push(`Estimated charge: ${amt}`);
  }
  if (trial.rawEmailUrl || trial.threadUrl) {
    descriptionLines.push(`Email: ${trial.threadUrl || trial.rawEmailUrl}`);
  }

  const description = descriptionLines.join("\\n");

  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Free-Trial Tripwire//EN",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${toIcsDate(new Date())}`,
    `DTSTART:${toIcsDate(start)}`,
    `DTEND:${toIcsDate(end)}`,
    `SUMMARY:${summary}`,
    `DESCRIPTION:${description}`,
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");
}

function triggerIcsDownload(trial) {
  const ics = buildIcsContent(trial);
  if (!ics) {
    alert("No charge date detected yet, so a calendar reminder can't be generated.");
    return;
  }

  const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const safeService = (trial.serviceName || "subscription").replace(/[^a-z0-9\-]+/gi, "_");
  a.href = url;
  a.download = `cancel-${safeService}.ics`;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 0);
}

// ------- Tab helpers -------

function openTrialEmail(trial) {
  const url = trial.threadUrl || trial.rawEmailUrl;
  if (!url) return;

  try {
    chrome.tabs.create({ url, active: true }, () => {
      const err = chrome.runtime.lastError;
      if (err) {
        console.error("[FTT popup] tabs.create failed", err);
        window.open(url, "_blank", "noopener");
      }
    });
  } catch (e) {
    console.error("[FTT popup] openTrialEmail fallback", e);
    window.open(url, "_blank", "noopener");
  }
}

// ------- Rendering -------

function applyFilter(trials) {
  if (currentFilter === "all") return trials;
  return trials.filter(t => t.type === currentFilter);
}

function renderSummary(trials) {
  const countEl = $("summary-count");
  const amountEl = $("summary-amount");
  const lastScanEl = $("last-scan-text");

  const filtered = applyFilter(trials);

  if (countEl) countEl.textContent = String(filtered.length);

  let total = 0;
  for (const t of filtered) {
    if (typeof t.amount === "number" && !isNaN(t.amount)) {
      total += t.amount;
    }
  }
  if (amountEl) {
    const formatted = total > 0 ? formatCurrency(total, "USD") : "$0.00";
    amountEl.textContent = formatted;
  }

  if (lastScanEl) {
    lastScanEl.textContent = formatLastScan(lastScanAt);
  }
}

function renderSummaryPills(trials) {
  const container = $("summary-pills");
  if (!container) return;

  // Clear existing
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }

  if (!trials.length) return;

  const totalTrials = trials.filter(t => t.type === "trial").length;
  const totalSubs = trials.filter(t => t.type === "subscription").length;

  const pillCounts = document.createElement("div");
  pillCounts.className = "summary-pill";
  pillCounts.innerHTML = `
    <span class="summary-pill-label">Trials/Subs</span>
    <span class="summary-pill-value">${totalTrials} / ${totalSubs}</span>
  `;
  container.appendChild(pillCounts);

  const now = Date.now();
  const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
  let atRiskTotal = 0;

  for (const t of trials) {
    if (!t.nextChargeDate || typeof t.amount !== "number" || isNaN(t.amount)) continue;
    const d = new Date(t.nextChargeDate);
    if (isNaN(d.getTime())) continue;
    const diff = d.getTime() - now;
    if (diff >= 0 && diff <= THIRTY_DAYS) {
      atRiskTotal += t.amount;
    }
  }

  if (atRiskTotal > 0) {
    const pillRisk = document.createElement("div");
    pillRisk.className = "summary-pill summary-pill--risk";
    pillRisk.innerHTML = `
      <span class="summary-pill-label">Next 30 days</span>
      <span class="summary-pill-value">${formatCurrency(atRiskTotal, "USD")}</span>
    `;
    container.appendChild(pillRisk);
  }
}

function renderTable(trials) {
  const tableBody = $("table-body");
  const emptyState = $("empty-state");
  if (!tableBody) return;

  // Clear existing rows
  while (tableBody.firstChild) {
    tableBody.removeChild(tableBody.firstChild);
  }

  const filtered = applyFilter(trials);

  if (!filtered.length) {
    if (emptyState) {
      tableBody.appendChild(emptyState);
      emptyState.style.display = "block";
    } else {
      const div = document.createElement("div");
      div.className = "empty-state";
      div.textContent =
        "No trials or subscriptions found in the current data. Try scanning your inbox.";
      tableBody.appendChild(div);
    }
    return;
  }

  if (emptyState) {
    emptyState.style.display = "none";
  }

  filtered.forEach(trial => {
    const row = document.createElement("div");
    row.className = "table-row";

    // Service cell
    const serviceCell = document.createElement("div");
    serviceCell.className = "cell-service";

    const serviceNameEl = document.createElement("div");
    serviceNameEl.className = "service-name";
    const urlToUse = trial.threadUrl || trial.rawEmailUrl;
    if (urlToUse) {
      const link = document.createElement("a");
      link.href = urlToUse;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = trial.serviceName || "Unknown service";
      link.style.color = "inherit";
      link.style.textDecoration = "none";
      serviceNameEl.appendChild(link);
    } else {
      serviceNameEl.textContent = trial.serviceName || "Unknown service";
    }

    const metaEl = document.createElement("div");
    metaEl.className = "service-meta";
    const pieces = [];
    if (trial.sender) pieces.push(trial.sender);
    if (trial.subject) pieces.push(trial.subject);
    metaEl.textContent = pieces.join(" · ").slice(0, 90);

    serviceCell.appendChild(serviceNameEl);
    serviceCell.appendChild(metaEl);

    // Type + confidence cell
    const typeCell = document.createElement("div");
    typeCell.className = "cell-type";
    const typeBadge = document.createElement("span");
    typeBadge.className =
      "badge-type " + (trial.type === "trial" ? "badge-type--trial" : "badge-type--sub");
    typeBadge.textContent = trial.type === "trial" ? "Trial" : "Sub";
    typeCell.appendChild(typeBadge);

    if (typeof trial.confidence === "number" && !isNaN(trial.confidence)) {
      const confTag = document.createElement("span");
      confTag.className = "badge-tag badge-tag--confidence";
      const pct = Math.round(trial.confidence * 100);
      confTag.textContent = `~${pct}%`;
      confTag.style.marginLeft = "4px";
      typeCell.appendChild(confTag);
    }

    // Date cell
    const dateCell = document.createElement("div");
    dateCell.className = "cell-date";
    const formattedDate = formatDate(trial.nextChargeDate);
    dateCell.textContent = formattedDate || "Unknown";

    // Amount + actions cell
    const amountCell = document.createElement("div");
    amountCell.className = "cell-amount";

    if (typeof trial.amount === "number" && !isNaN(trial.amount)) {
      const amtSpan = document.createElement("span");
      amtSpan.textContent = formatCurrency(trial.amount, trial.currency || "USD");
      amountCell.appendChild(amtSpan);
    } else {
      amountCell.classList.add("cell-amount--missing");
      amountCell.textContent = "—";
    }

    // Row actions: Open + Remind
    const actionsContainer = document.createElement("div");
    actionsContainer.className = "cell-actions";

    if (trial.threadUrl || trial.rawEmailUrl) {
      const openBtn = document.createElement("button");
      openBtn.type = "button";
      openBtn.textContent = "Open";
      openBtn.className = "row-action row-action--primary";
      openBtn.addEventListener("click", e => {
        e.stopPropagation();
        openTrialEmail(trial);
      });
      actionsContainer.appendChild(openBtn);
    }

    if (trial.nextChargeDate) {
      const remindBtn = document.createElement("button");
      remindBtn.type = "button";
      remindBtn.textContent = "Remind";
      remindBtn.className = "row-action";
      remindBtn.addEventListener("click", e => {
        e.stopPropagation();
        triggerIcsDownload(trial);
      });
      actionsContainer.appendChild(remindBtn);
    }

    if (actionsContainer.childElementCount > 0) {
      // small gap between amount and actions
      if (amountCell.textContent && amountCell.textContent.trim() !== "—") {
        const spacer = document.createElement("div");
        spacer.style.height = "4px";
        amountCell.appendChild(spacer);
      }
      amountCell.appendChild(actionsContainer);
    }

    row.appendChild(serviceCell);
    row.appendChild(typeCell);
    row.appendChild(dateCell);
    row.appendChild(amountCell);

    tableBody.appendChild(row);
  });
}

function renderAll() {
  renderSummary(allTrials);
  renderSummaryPills(allTrials);
  renderTable(allTrials);
}

// ------- Filters -------

function setFilter(filter) {
  currentFilter = filter;
  const chips = document.querySelectorAll(".chip");
  chips.forEach(chip => {
    if (chip.dataset.filter === filter) {
      chip.classList.add("chip--active");
    } else {
      chip.classList.remove("chip--active");
    }
  });
  renderAll();
}

// ------- Messaging -------

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(message, response => {
        const err = chrome.runtime.lastError;
        if (err) {
          reject(err);
          return;
        }
        resolve(response);
      });
    } catch (e) {
      reject(e);
    }
  });
}

async function requestInitialTrials() {
  try {
    const res = await sendMessage({ type: MSG.GET_TRIALS });
    if (!res || !res.ok) {
      renderAll();
      return;
    }
    allTrials = Array.isArray(res.trials) ? res.trials : [];
    lastScanAt = res.lastScanAt || null;
    renderAll();
  } catch (e) {
    console.error("[FTT popup] Failed to load initial trials", e);
    renderAll();
  }
}

async function startScan() {
  setStatus("scanning", "Scanning…");
  const btn = $("scan-btn");
  if (btn) btn.disabled = true;

  try {
    const res = await sendMessage({ type: MSG.START_SCAN });
    if (!res) {
      setStatus("error", "Scan failed");
    } else if (res.busy) {
      setStatus("scanning", "Already scanning…");
    } else if (!res.ok) {
      setStatus("error", "Scan failed");
    } else {
      setStatus("scanning", "Scanning Gmail…");
    }
  } catch (e) {
    console.error("[FTT popup] Scan request failed", e);
    setStatus("error", "Scan failed");
  } finally {
    if (btn) {
      setTimeout(() => {
        btn.disabled = false;
      }, 800);
    }
  }
}

// ------- Incoming messages -------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  if (message.type === MSG.PROGRESS) {
    const stage = message.stage || "";
    if (stage === "starting" || stage === "opening_gmail" || stage === "injecting") {
      setStatus("scanning", "Scanning Gmail…");
    } else if (stage === "waiting_results") {
      setStatus("scanning", "Waiting for results…");
    } else if (stage === "scanner_scanning") {
      setStatus("scanning", "Scanning emails…");
    } else if (stage === "scanner_done") {
      setStatus("done", "Scan complete");
      setTimeout(() => setStatus("idle", "Idle"), 2000);
    } else if (stage === "busy") {
      setStatus("scanning", "Already scanning…");
    } else if (stage === "scanner_error" || stage === "error") {
      setStatus("error", "Scan error");
    }
  }

  if (message.type === MSG.TRIALS_UPDATED) {
    allTrials = Array.isArray(message.trials) ? message.trials : [];
    lastScanAt = message.lastScanAt || lastScanAt || null;
    renderAll();
  }
});

// ------- Init -------

document.addEventListener("DOMContentLoaded", () => {
  setStatus("idle", "Idle");

  const scanBtn = $("scan-btn");
  if (scanBtn) {
    scanBtn.addEventListener("click", () => {
      startScan();
    });
  }

  const filterAll = $("filter-all");
  const filterTrial = $("filter-trial");
  const filterSub = $("filter-sub");

  if (filterAll) filterAll.addEventListener("click", () => setFilter("all"));
  if (filterTrial) filterTrial.addEventListener("click", () => setFilter("trial"));
  if (filterSub) filterSub.addEventListener("click", () => setFilter("subscription"));

  requestInitialTrials().catch(err => {
    console.error("[FTT popup] init error", err);
  });
});
