﻿// background.js

// URL match for Gmail tabs
const GMAIL_URL_MATCH = "*://mail.google.com/*";
const GMAIL_INBOX_URL = "https://mail.google.com/mail/u/0/#inbox";
const GMAIL_LOAD_TIMEOUT_MS = 20000; // 20s timeout for Gmail to finish loading

const MSG = {
  START_SCAN: "FTT_START_SCAN",      // from popup → background
  SCAN_RESULTS: "FTT_SCAN_RESULTS",  // from gmailScanner → background
  GET_TRIALS: "FTT_GET_TRIALS",      // from popup → background
  TRIALS_UPDATED: "FTT_TRIALS_UPDATED",
  PROGRESS: "FTT_PROGRESS"
};

let isScanInProgress = false;

// ------------ Small helpers ------------

function sendProgress(stage, details) {
  try {
    if (!chrome.runtime || !chrome.runtime.id) return;
    chrome.runtime.sendMessage({
      type: MSG.PROGRESS,
      stage,
      details: details || null
    });
  } catch (e) {
    // ok if no listeners / context
  }
}

function queryTabs(query) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query(query, tabs => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(tabs || []);
      }
    });
  });
}

function createTab(createProps) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create(createProps, tab => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(tab || null);
      }
    });
  });
}

function executeScript(target, files) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      { target, files },
      results => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(results || []);
        }
      }
    );
  });
}

function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, result => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result || {});
      }
    });
  });
}

function storageSet(items) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(items, () => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve();
      }
    });
  });
}

function waitForTabComplete(tabId, timeoutMs = GMAIL_LOAD_TIMEOUT_MS) {
  return new Promise(resolve => {
    if (typeof tabId !== "number") {
      resolve(null);
      return;
    }

    let timeoutId = null;

    function cleanup(result) {
      try {
        chrome.tabs.onUpdated.removeListener(listener);
      } catch {
        // ignore
      }
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      resolve(result);
    }

    function listener(updatedId, changeInfo, tab) {
      if (updatedId === tabId && changeInfo.status === "complete") {
        cleanup(tab);
      }
    }

    chrome.tabs.onUpdated.addListener(listener);

    timeoutId = setTimeout(() => {
      cleanup(null);
    }, timeoutMs);
  });
}

// ------------ Core logic ------------

async function findOrOpenGmailTab() {
  const tabs = await queryTabs({ url: GMAIL_URL_MATCH });

  if (tabs.length > 0) {
    const tab = tabs[0];
    if (typeof tab.id === "number") {
      return tab;
    }
    throw new Error("Found Gmail tab without a valid id.");
  }

  sendProgress("opening_gmail", "No Gmail tab found, opening inbox.");
  const newTab = await createTab({
    url: GMAIL_INBOX_URL,
    active: true
  });

  if (!newTab || typeof newTab.id !== "number") {
    throw new Error("Failed to create Gmail tab.");
  }

  const loadedTab = await waitForTabComplete(newTab.id);
  if (!loadedTab) {
    throw new Error("Timed out waiting for Gmail to load.");
  }

  return loadedTab;
}

/**
 * Starts a Gmail scan if one is not already running.
 * @returns {Promise<boolean>} true if a new scan started, false if already busy
 */
async function runGmailScan() {
  if (isScanInProgress) {
    sendProgress("busy", "A scan is already running.");
    return false;
  }

  isScanInProgress = true;
  try {
    sendProgress("starting", "Locating Gmail tab...");
    const gmailTab = await findOrOpenGmailTab();

    if (!gmailTab || typeof gmailTab.id !== "number") {
      throw new Error("Unable to identify a valid Gmail tab.");
    }

    sendProgress("injecting", "Injecting scanner into Gmail...");
    await executeScript({ tabId: gmailTab.id }, ["gmailScanner.js"]);

    // gmailScanner.js is responsible for scanning and sending
    // a message { type: MSG.SCAN_RESULTS, trials: [...] }
    sendProgress("waiting_results", "Waiting for scan results...");
    return true;
  } finally {
    // The actual end-of-scan UX is driven by SCAN_RESULTS / TRIALS_UPDATED
    isScanInProgress = false;
  }
}

async function mergeTrials(newTrials) {
  if (!Array.isArray(newTrials) || newTrials.length === 0) return;

  const now = Date.now();

  const data = await storageGet(["trialsById"]);
  const trialsById = (data && typeof data.trialsById === "object" && data.trialsById) || {};

  for (const t of newTrials) {
    if (!t || !t.id) continue;

    const id = String(t.id);
    const existing = trialsById[id] || {};

    trialsById[id] = Object.assign(
      {},
      existing,
      t,
      {
        id,
        firstSeenAt: existing.firstSeenAt || existing.createdAt || now,
        lastSeenAt: now
      }
    );
  }

  const lastScanAt = now;
  await storageSet({ trialsById, lastScanAt });

  try {
    chrome.runtime.sendMessage({
      type: MSG.TRIALS_UPDATED,
      lastScanAt,
      trials: Object.values(trialsById)
    });
  } catch (e) {
    // fine if popup isn't open
  }
}

// ------------ Message routing ------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  // Popup → start a scan
  if (message.type === MSG.START_SCAN) {
    (async () => {
      try {
        const started = await runGmailScan();
        sendResponse({ ok: started, busy: !started });
      } catch (err) {
        console.error("[FTT] Scan failed", err);
        const msg = String((err && err.message) || err);
        sendProgress("error", msg);
        sendResponse({ ok: false, error: msg });
      }
    })();
    return true; // keep sendResponse alive
  }

  // gmailScanner → results
  if (message.type === MSG.SCAN_RESULTS) {
    (async () => {
      try {
        await mergeTrials(message.trials || []);
      } catch (err) {
        console.error("[FTT] Failed to merge trials", err);
      }
    })();
    // no response needed
  }

  // Popup → load existing trials
  if (message.type === MSG.GET_TRIALS) {
    (async () => {
      try {
        const data = await storageGet(["trialsById", "lastScanAt"]);
        const trialsById = (data && data.trialsById) || {};
        sendResponse({
          ok: true,
          trials: Object.values(trialsById),
          lastScanAt: data.lastScanAt || null
        });
      } catch (err) {
        console.error("[FTT] Failed to load trials", err);
        sendResponse({
          ok: false,
          error: String((err && err.message) || err)
        });
      }
    })();
    return true;
  }
});
