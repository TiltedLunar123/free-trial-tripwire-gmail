# Changelog

All notable changes to this project will be documented in this file.

## [0.2.0] - 2025-11-30

### Changed
- Hardened scan flow in `background.js`:
  - Added single-scan “busy” lock to avoid overlapping scans.
  - Added Gmail tab detection with load timeout and stricter tab ID checks.
  - Made progress / error reporting more defensive and explicit.
  - Enriched stored trial records with `firstSeenAt` and `lastSeenAt` metadata.
- Improved error handling around `chrome.tabs`, `chrome.scripting`, and `chrome.storage` calls.

### Fixed
- Cases where:
  - A Gmail tab existed but had no valid `id`.
  - The extension could hang waiting for Gmail to finish loading.
  - Storage operations could fail silently and leave the popup in a bad state.

---

## [0.1.0] - 2025-11-29

### Added
- Initial scaffold for **Free-Trial Tripwire for Gmail**:
  - Basic popup, background, and Gmail scanner wiring.
  - Local storage of detected trials keyed by `id`.
  - Simple progress messages from background → popup during scans.
